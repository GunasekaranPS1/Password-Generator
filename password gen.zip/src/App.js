
import './App.css';
import PassGenerator from './PassGenerator';

function App() {
  return (
    <div className="App">
    <PassGenerator/>
    </div>
  );
}

export default App;
